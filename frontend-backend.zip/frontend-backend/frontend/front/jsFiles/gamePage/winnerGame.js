function winnerGame() {
    return `
    <head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Press+Start+2P&display=swap">
    <style>

    body {
        background-color: #15202b;
        height: 100vh;
        margin: 0;
        overflow-x: hidden;
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    #canvas-container {
        position: relative;
        width: 90vw;
        height: 80vh;
        max-width: 900px;
        max-height: 600px;
        margin: 30px auto;
        /* box-shadow: 0 0 1.25em 0.5em greenyellow; */
    }

    canvas {
        /* display: grid; */
        background-color: #000;
        /* border: 2px solid greenyellow; */
        border-radius: 10px;
        width: 100%;
        height: 100%;
        /* box-shadow: 0 0 1.25em 0.5em greenyellow; */
    }

    #scoreboard {
        position: absolute;
        top: 10px;
        left: 50%;
        transform: translateX(-50%);
        display: flex;
        justify-content: space-between;
        width: 80%;
        z-index: 1;
    }

    #player1Score, #player2Score {
        color: white;
        /* font-family: 'Poppins', sans-serif; */
        /* font-family: 'Courier New', Courier, monospace; */
        font-family: 'Press Start 2P', cursive;
        font-size: 44px;
    }

    #First {
        position: absolute;
        color: white;
        font-family: 'Poppins', sans-serif;
        font-size: 2rem;
        font-weight: bold;
        top: 20%;
        left: 50%;
        transform: translate(-50%, -50%);
        opacity: 0;
        animation: fadeIn 1s ease forwards;
        z-index: 1;
        text-align: center;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translate(-50%, -50%) scale(0.5);
        }
        to {
            opacity: 1;
            transform: translate(-50%, -50%) scale(1);
        }
    }

    @media screen and (max-width: 768px) {
        #scoreboard {
            font-size: 18px;
        }
    }

    @media screen and (max-width: 480px) {
        #scoreboard {
            font-size: 16px;
        }
    }

    .btn-group{
        left: 50%;
        transform: translateX(-50%);
        display: flex;
        justify-content: space-between;
    }

</style>
</head>
    <div id="canvas-container">
        <canvas id="canvas"></canvas>
        <h2 id ="First">Winner is : ${winnerUser}</h2>
    </div>

    `;
}
